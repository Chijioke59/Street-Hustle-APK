STREET HUSTLE - PHONE APK BUILD

This project is prepared for GitHub Actions. The workflow at:
.github/workflows/build-apk.yml
will compile the Android app and upload the APK as an artifact.

PHONE STEPS
1. Create a GitHub account or sign in at github.com.
2. Create a NEW repository named Street-Hustle.
3. Upload ALL files and folders from this project into the repository root.
4. Open the repository's Actions tab.
5. Select "Build Street Hustle APK".
6. Tap "Run workflow" and run it from the main branch.
7. Wait for the green checkmark.
8. Open the completed workflow run.
9. Under Artifacts, tap "Street-Hustle-APK".
10. Download the ZIP artifact, open it, and install app-debug.apk on your phone.

IMPORTANT
- This is a DEBUG/test APK, not a signed Play Store release APK.
- Android may ask you to allow installation from your browser/file manager.
- The current game is the all-in-one prototype and uses local device storage.
- Online accounts, multiplayer, cloud saves, server-side marketplace/court,
  and Google Play Billing are not yet implemented.
