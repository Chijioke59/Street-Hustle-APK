STREET HUSTLE — SIMPLE APK BUILD

This is the complete Android project. Upload its contents to the ROOT of your GitHub repository.

Required top-level items:
app/
build.gradle
settings.gradle
README.txt
README_GITHUB_APK.txt

Do NOT upload this ZIP as the project itself.
